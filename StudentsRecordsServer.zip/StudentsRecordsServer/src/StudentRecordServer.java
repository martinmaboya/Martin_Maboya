/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 * 222927380
 */
public class StudentRecordServer {
    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static ServerSocket serverSocket;
    private static Socket clientSocket;
    private static Object receivedObject;
    private static List<Student> studentRecords = new ArrayList<>();

//In the constructor listen for incoming client connections    
    public StudentRecordServer() {
        try {
            serverSocket = new ServerSocket(12345, 1);
            System.out.println("Server listening on port 12345");
            
            clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
            getStreams();
            processClient();
            
        } catch (IOException ioe) {
            System.out.println("Exception: " + ioe.getMessage());
        }
    }//end constructor

//------------------------------------------------------------------------------    
    
//create the io streams
public void getStreams(){
    try {
        out = new ObjectOutputStream(clientSocket.getOutputStream());
        in = new ObjectInputStream(clientSocket.getInputStream());
    } catch (IOException e) {
        System.out.println("IOException: " + e.getMessage());
        }
}//end getStreams()

//------------------------------------------------------------------------------    
    
//Declare arraylist and handle the communication between server and client    
    public void processClient() {
        
        try {
            List<Student> studentRecords = new ArrayList<>();
            receivedObject = in.readObject();
            if (receivedObject instanceof Student) {
                studentRecords.add((Student) receivedObject);
                JOptionPane.showMessageDialog(null, receivedObject);
            } else if (receivedObject instanceof String) {
                if (((String) receivedObject).equals("RETRIEVE")) {
                    out.writeObject(studentRecords);
                    out.flush();
                }
            }
        
            
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentRecordServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//end processClient

//------------------------------------------------------------------------------    

//close all connections to the server and exit the application   
    private static void closeConnection() {
        try {
            out.close();
            in.close();
            clientSocket.close();
        } catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
    }//end closeConnection()

//------------------------------------------------------------------------------    

//execute the program and call all necessary methods
    public static void main(String[] args) {
        StudentRecordServer sr = new StudentRecordServer();
        //sr.processClient();
        //sr.getStreams();
        //StudentRecordServer.closeConnection();
    
    }//end main

}//end class

