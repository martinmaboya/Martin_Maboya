/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnrollmentDAO;
import CourseDAO.Course;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class EnrollmentDAO {
    private Connection connection;

    public EnrollmentDAO(Connection connection) {
        this.connection = connection;
    }

    public void enrollStudentInCourse(int studentId, int courseId) {
        String sql = "INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, NOW())";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, courseId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Course> getEnrollmentsByUsername(String username) {
        List<Course> enrolledCourses = new ArrayList<>();
        String sql = "SELECT c.course_id, c.course_code, c.title FROM Courses c " +
                     "INNER JOIN Enrollments e ON c.course_id = e.course_id " +
                     "INNER JOIN Students s ON e.student_id = s.student_id " +
                     "WHERE s.username = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int courseId = resultSet.getInt("course_id");
                String courseCode = resultSet.getString("course_code");
                String title = resultSet.getString("title");
                Course course = new Course(courseCode, title);
                enrolledCourses.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return enrolledCourses;
    }

    // You can add more methods for enrollment management as needed
}
