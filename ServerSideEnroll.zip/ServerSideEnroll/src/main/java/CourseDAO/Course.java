/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CourseDAO;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class Course {
    String coursecode;
    String title;

//    public Course(String courseCode, String title) {
//    }

    public Course(String coursecode, String title) {
        this.coursecode = coursecode;
        this.title = title;
    }

    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Course{" + "coursecode=" + coursecode + ", title=" + title + '}';
    }
          
}
