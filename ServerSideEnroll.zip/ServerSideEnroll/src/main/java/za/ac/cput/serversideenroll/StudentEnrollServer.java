/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.cput.serversideenroll;
import CourseDAO.Course;
import EnrollmentDAO.EnrollmentDAO;
import StudentDAO.Student;
import StudentDAO.StudentDAO;
import UserDAO.UserDAO;
import CourseDAO.CourseDAO;
import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class StudentEnrollServer {
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private Object receivedObject;
    private static List<Student> studentDatabase; // ArrayList to store enrollment data
    private StudentDAO studentDAO;
    private CourseDAO courseDAO;
    private UserDAO userDAO;
    private EnrollmentDAO enrollmentDAO;

    public StudentEnrollServer() throws SQLException {
        try {
            DBConnection dbConnection = new DBConnection(); // Create an instance of DBConnection
            Connection connection = dbConnection.getConnection(); // Get a database connection
            studentDAO = new StudentDAO(connection);
            courseDAO = new CourseDAO(connection);
            userDAO = new UserDAO(connection);
            enrollmentDAO = new EnrollmentDAO(connection);

            serverSocket = new ServerSocket(12345, 1);
            System.out.println("Server listening on port 12345");
            clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getStreams() {
        try {
            System.out.println("Waiting for a client to connect...");
            clientSocket = serverSocket.accept();
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(clientSocket.getInputStream());
            System.out.println("Connected to client.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Handles the communication between server and client
    public void processClient() {
        try {
            while (true) {
                // Receive a request from the client
                receivedObject = in.readObject();
                if (receivedObject instanceof EnrollmentRequest) {
                    EnrollmentRequest request = (EnrollmentRequest) receivedObject;
                    if (authenticateUser(request.getUsername(), request.getPassword()) != null) {
                        String role = authenticateUser(request.getUsername(), request.getPassword());
                        if ("admin".equalsIgnoreCase(role)) {
                            enrollStudent(request.getStudent());
                        } else if ("student".equalsIgnoreCase(role)) {
                            sendEnrollmentData(request.getUsername());
                        }
                    } else {
                        // Authentication failed, send a message to the client
                        out.writeObject("Authentication failed");
                        out.flush();
                    }
                }
            }
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }

    // Store enrollment data in the database
    private void enrollStudent(Student student) {
        studentDAO.addStudent(student);
    }

    // Retrieve enrollment data for a specific user
    private void sendEnrollmentData(String username) {
        List<Course> userEnrollments = enrollmentDAO.getEnrollmentsByUsername(username);
        try {
            out.writeObject(userEnrollments);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Authenticate admin and student users
    private String authenticateUser(String username, String password) {
        // Use the UserDAO to authenticate the user
        return userDAO.authenticate(username, password);
    }

    private void closeConnection() {
        try {
            out.close();
            in.close();
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException {
        studentDatabase = new ArrayList<>();
        StudentEnrollServer server = new StudentEnrollServer();
        server.getStreams();
        server.processClient();
        server.closeConnection();
    }
}
