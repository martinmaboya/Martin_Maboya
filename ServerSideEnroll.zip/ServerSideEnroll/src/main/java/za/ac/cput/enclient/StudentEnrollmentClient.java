/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.cput.enclient;
import CourseDAO.Course;
import StudentDAO.Student;
import UserDAO.UserDAO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.cput.serversideenroll.DBConnection;
import za.ac.cput.serversideenroll.EnrollmentRequest;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class StudentEnrollmentClient {
    private JFrame frame;
    private JPanel loginPanel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static Socket socket;

    public StudentEnrollmentClient() {
//        try{
//        socket = new Socket("127.0.0.1", 12345);
//        out = new ObjectOutputStream(socket.getOutputStream());
//        in = new ObjectInputStream(socket.getInputStream());
//        System.out.println("Connected");  
//        } catch (IOException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//           }
        // Initialize the frame
        frame = new JFrame("Student Enrollment System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new BorderLayout());

        // Create login panel
        loginPanel = new JPanel(new GridLayout(3, 2));

        // Username label and field
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);

        // Password label and field
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);

        // Login button
        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Handle login logic here
                    String enteredUsername = usernameField.getText();
                    char[] enteredPasswordChars = passwordField.getPassword();
                    String enteredPassword = new String(enteredPasswordChars);
                    
                    DBConnection dbconnection = new DBConnection();
                    Connection connection = dbconnection.getConnection();
                    
                    // Create an instance of the UserDAO class with the database connection
                    UserDAO userDAO = new UserDAO(connection);
                    // Authenticate the user and retrieve their role
                    String role = userDAO.authenticate(enteredUsername, enteredPassword); // Assuming authenticate returns a String
                    if (role != null && !role.isEmpty()) {
                        if ("admin".equalsIgnoreCase(role)) {
                            showAdminFunctionality();
                        } else if ("student".equalsIgnoreCase(role)) {
                            showStudentFunctionality();
                        } else {
                            JOptionPane.showMessageDialog(frame, "Unknown user role. Contact the administrator.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Authentication failed. Please check your credentials.");
                    }
                    
                    
                    // Perform user authentication and role-based functionality here
                    // For simplicity, we'll assume admin and student have the same credentials
                    if ("admin".equalsIgnoreCase(enteredUsername) && "password".equals(enteredPassword)) {
                        showAdminFunctionality();
                    } else if ("student".equalsIgnoreCase(enteredUsername) && "password".equals(enteredPassword)) {
                        showStudentFunctionality();
                    } else {
                        JOptionPane.showMessageDialog(frame, "Authentication failed. Please check your credentials.");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        loginPanel.add(loginButton);

        // Add the login panel to the frame
        frame.add(loginPanel, BorderLayout.CENTER);

        // Display the frame
        frame.setVisible(true);
    }

    private void showAdminFunctionality() {
        frame.getContentPane().removeAll(); // Clear the login panel
        frame.revalidate();
        frame.repaint();

        // Create and display the admin panel with admin-specific functionality
        JPanel adminPanel = new JPanel();
        adminPanel.setLayout(new BorderLayout());

        JLabel adminLabel = new JLabel("Admin Functionality");
        adminPanel.add(adminLabel, BorderLayout.NORTH);

        JButton addButton = new JButton("Add Course");
        adminPanel.add(addButton, BorderLayout.CENTER);

        frame.add(adminPanel);
        frame.revalidate();
        frame.repaint();
    }

    private void showStudentFunctionality() {
        frame.getContentPane().removeAll(); // Clear the login panel
        frame.revalidate();
        frame.repaint();

        // Create and display the student panel with student-specific functionality
        JPanel studentPanel = new JPanel();
        studentPanel.setLayout(new BorderLayout());

        JLabel studentLabel = new JLabel("Student Functionality");
        studentPanel.add(studentLabel, BorderLayout.NORTH);

        JButton enrollButton = new JButton("Enroll in Course");
        enrollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle enrolling in a course here
                enrollInCourse();
            }
        });

        JButton displayCoursesButton = new JButton("Display Available Courses");
        displayCoursesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle displaying available courses here
                displayAvailableCourses();
            }
        });

        studentPanel.add(displayCoursesButton, BorderLayout.CENTER);
        studentPanel.add(enrollButton, BorderLayout.SOUTH);

        frame.add(studentPanel);
        frame.revalidate();
        frame.repaint();
    }
    private void addNewCourse() {
        // Create a dialog to collect course details
        JPanel coursePanel = new JPanel(new GridLayout(3, 2));

        JLabel courseCodeLabel = new JLabel("Course Code:");
        JTextField courseCodeField = new JTextField();
        coursePanel.add(courseCodeLabel);
        coursePanel.add(courseCodeField);

        JLabel courseNameLabel = new JLabel("Course Name:");
        JTextField courseNameField = new JTextField();
        coursePanel.add(courseNameLabel);
        coursePanel.add(courseNameField);

        JLabel courseDescriptionLabel = new JLabel("Course Description:");
        JTextField courseDescriptionField = new JTextField();
        coursePanel.add(courseDescriptionLabel);
        coursePanel.add(courseDescriptionField);

        int result = JOptionPane.showConfirmDialog(
                frame,
                coursePanel,
                "Add New Course",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result == JOptionPane.OK_OPTION) {
            String code = courseCodeField.getText();
            String name = courseNameField.getText();
            String description = courseDescriptionField.getText();

            // Check if any field is empty
            if (code.isEmpty() || name.isEmpty() || description.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields must be filled.");
            } else {
                // Create a new Course object with the collected data
                Course newCourse = new Course(code, name);

                // Send the new course data to the server (you should implement this method)
                sendNewCourseToServer(newCourse);

                // Display a confirmation message or handle server response
                JOptionPane.showMessageDialog(frame, "New course added successfully.");
            }
        }
    }      
    private void sendNewCourseToServer(Course newCourse) {
        try {
            // Send the new course object to the server
            out.writeObject("AddNewCourse");
            out.writeObject(newCourse);

            // Handle the server's response (if any)
            // For example, display a confirmation message
            Object response = in.readObject();
            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     private void addNewStudent() {
        // Create a dialog to collect student details
        JPanel studentPanel = new JPanel(new GridLayout(3, 2));

        JLabel studentIDLabel = new JLabel("Student ID:");
        JTextField studentIDField = new JTextField();
        studentPanel.add(studentIDLabel);
        studentPanel.add(studentIDField);

        JLabel firstNameLabel = new JLabel("First Name:");
        JTextField firstNameField = new JTextField();
        studentPanel.add(firstNameLabel);
        studentPanel.add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        JTextField lastNameField = new JTextField();
        studentPanel.add(lastNameLabel);
        studentPanel.add(lastNameField);

        int result = JOptionPane.showConfirmDialog(
                frame,
                studentPanel,
                "Add New Student",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result == JOptionPane.OK_OPTION) {
            String studentID = studentIDField.getText();
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();

            // Check if any field is empty
            if (studentID.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields must be filled.");
            } else {
                // Create a new Student object with the collected data
                Student newStudent = new Student(studentID, firstName, lastName);

                // Send the new student data to the server (you should implement this method)
                sendNewStudentToServer(newStudent);

                // Display a confirmation message or handle server response
                JOptionPane.showMessageDialog(frame, "New student added successfully.");
            }
        }
    }

    // Method to send the new student data to the server
    private void sendNewStudentToServer(Student newStudent) {
        try {
            // Send the new student object to the server
            out.writeObject("AddNewStudent");
            out.writeObject(newStudent);

            // Handle the server's response (if any)
            // For example, display a confirmation message
            Object response = in.readObject();
            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void displayAvailableCourses() {
        // Implement the logic to display a list of available courses (student functionality)
        // You can fetch and display the courses from the database
        JOptionPane.showMessageDialog(frame, "Display Available Courses - Student Functionality");
    }

    private void enrollInCourse() {
        // Implement the logic to allow students to enroll in a course (student functionality)
        // You can provide a list of available courses and allow students to select and enroll
        JOptionPane.showMessageDialog(frame, "Enroll in Course - Student Functionality");
    }

    public static void connectToServer(){
        try {
            socket = new Socket("127.0.0.1", 12345); 
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            System.out.println("Connected to the server.");
        } catch (IOException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    // Method to send enrollment requests to the server (for students)
    private void sendEnrollmentRequest(String studentUsername, String courseCode) {
        try {
            // Create an enrollment request object and send it to the server
            EnrollmentRequest enrollmentRequest = new EnrollmentRequest(studentUsername, courseCode);
            out.writeObject(enrollmentRequest);

            // Handle the server's response (if any)
            // For example, display a confirmation message
            Object response = in.readObject();
            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Method to send course and student data to the server (for admins)
//    private void sendCourseAndStudentData(List<Course> courses, List<Student> students) {
//        try {
//            // Create a data object containing courses and students and send it to the server
//            DataObject dataObject = new DataObject(courses, students);
//            out.writeObject(dataObject);
//
//            // Handle the server's response (if any)
//            // For example, display a confirmation message
//            Object response = in.readObject();
//            if (response instanceof String) {
//                String message = (String) response;
//                JOptionPane.showMessageDialog(frame, message);
//            }
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//    // Method to request and receive available courses from the server
//    private List<Course> receiveAvailableCourses() {
//        try {
//            // Send a request to the server for available courses
//            out.writeObject("GetAvailableCourses");
//
//            // Receive and return the list of available courses from the server
//            Object response = in.readObject();
//            if (response instanceof List<?>) {
//                return (List<Course>) response;
//            }
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return null;
//    }
//
//    // Method to send a request for all students enrolled in a particular course
//    private void requestStudentsInCourse(String courseCode) {
//        try {
//            // Send a request for students in a course to the server
//            out.writeObject("GetStudentsInCourse");
//            out.writeObject(courseCode);
//
//            // Handle the server's response (list of students)
//            Object response = in.readObject();
//            if (response instanceof List<?>) {
//                List<Student> students = (List<Student>) response;
//                // Display the list of students (e.g., in a dialog or table)
//                // ...
//            }
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

    // Method to send a request for enrollment data for a particular student
//    private void requestEnrollmentData(String studentUsername) {
//        try {
//            // Send a request for enrollment data to the server
//            out.writeObject("GetEnrollmentData");
//            out.writeObject(studentUsername);
//
//            // Handle the server's response (list of courses)
//            Object response = in.readObject();
//            if (response instanceof List<>) {
//                // Display the list of enrolled courses (e.g., in a dialog or table)
//                // ...
//                
//            }
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

//    private List<Course> requestAvailableCourses() {
//        try {
//            out.writeObject("GetAvailableCourses");
//            Object response = in.readObject();
//            if (response instanceof List<?>) {
//                return (List<Course>) response;
//            }
//        } catch (IOException | ClassNotFoundException ex) {
//            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return null;
//    }
//    private void displayAvailableCourses() {
//        List<Course> availableCourses = requestAvailableCourses();
//
//        if (availableCourses != null) {
//            DefaultListModel<Course> listModel = new DefaultListModel<>();
//            for (Course course : availableCourses) {
//                listModel.addElement(course);
//            }
//            JList<Course> courseList = new JList<>(listModel);
//            JOptionPane.showMessageDialog(frame, new JScrollPane(courseList), "Available Courses", JOptionPane.INFORMATION_MESSAGE);
//        } else {
//            JOptionPane.showMessageDialog(frame, "Failed to fetch available courses.", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }

    public static void main(String[] args) {  
              
        StudentEnrollmentClient studentEnrollmentClient = new StudentEnrollmentClient();
        studentEnrollmentClient.connectToServer();
               
    // Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
                
            
}
}

