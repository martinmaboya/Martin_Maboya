/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.serversideenroll;
import StudentDAO.Student;
import java.io.Serializable;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */


public class EnrollmentRequest implements Serializable {
    private String username;
    private String password;
    private boolean enroll;
    private Student student;

    public EnrollmentRequest(String username, String password) {
        this.username = username;
        this.password = password;
        this.enroll = enroll;
        this.student = student;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEnroll() {
        return enroll;
    }

    public void setEnroll(boolean enroll) {
        this.enroll = enroll;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
