/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StudentDAO;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class Student {
    private int Id;
    private String studentName;
    private String Studentnumber;

    public Student(String studentID, String firstName, String lastName) {
    }
    
    public Student(int Id, String studentName, String Studentnumber) {
        this.Id = Id;
        this.studentName = studentName;
        this.Studentnumber = Studentnumber;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }
    
    public String getstudentName() {
        return studentName;
    }
    

    public void setstudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentnumber() {
        return Studentnumber;
    }

    public void setStudentnumber(String Studentnumber) {
        this.Studentnumber = Studentnumber;
    }

    @Override
    public String toString() {
        return "Stundent{" + "studentName=" + studentName + ", Studentnumber=" + Studentnumber + '}';
    }
    
    
    
}
