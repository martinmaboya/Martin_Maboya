
package za.ac.cput.tut2A222583223;

import java.io.Serializable;

/**
 *
 * @author Martin Maboya 222583223
 */
public class VotingPoll implements Serializable {
    private String vehicleFinalist;
    private int numVotes;

    public VotingPoll(String vehicleFinalist, int numVotes) {
        this.vehicleFinalist = vehicleFinalist;
        this.numVotes = numVotes;
    }

    public String getvehicleFinalist() {
        return vehicleFinalist;
    }

    public void setvehicleFinalist(String vehicleFinalist) {
        this.vehicleFinalist = vehicleFinalist;
    }

    public int getNumVotes() {
        return numVotes;
    }

    public void setNumVotes(int numVotes) {
        this.numVotes = numVotes;
    }

    @Override
    public String toString() {
        return "VotingPoll{" + "vehicleFinalist=" + vehicleFinalist + ", numVotes=" + numVotes + '}';
    }

    void increaseNumVotes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
     
}
