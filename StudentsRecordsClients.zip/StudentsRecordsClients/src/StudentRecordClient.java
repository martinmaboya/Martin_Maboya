/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class StudentRecordClient implements ActionListener{
    private static ObjectInputStream in;
    private static ObjectOutputStream out;
    private static JFrame frame;
    private static JTextField nameField;
    private static JTextField idField;
    private static JTextField scoreField;
    private static JTextArea recordsTextArea;
    private static JButton addButton;
    private static JButton retrieveButton;
    private static JButton exitButton;
    private static Socket socket;

// Connect to the server, create io streams, and call the method that defines the gui
    public StudentRecordClient() {
        try {
            socket = new Socket("127.0.0.1", 12345);
            System.out.println("Connected to server on " + socket.getInetAddress().getHostAddress());

            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();

            in = new ObjectInputStream(socket.getInputStream());
            createAndShowGUI();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//end constructor

//------------------------------------------------------------------------------    

//Create the swing-based gui
    private void createAndShowGUI() {
    frame = new JFrame("Student Record Management");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(500, 400);
    frame.setLayout(new BorderLayout());

    JPanel inputPanel = new JPanel(new GridLayout(3, 2));
    inputPanel.add(new JLabel("Name:"));
    nameField = new JTextField();
    inputPanel.add(nameField);
    inputPanel.add(new JLabel("ID:"));
    idField = new JTextField();
    inputPanel.add(idField);
    inputPanel.add(new JLabel("Score:"));
    scoreField = new JTextField();
    inputPanel.add(scoreField);

    frame.add(inputPanel, BorderLayout.NORTH);

    addButton = new JButton("Add Record");
    addButton.addActionListener(this);
    retrieveButton = new JButton("Retrieve Records");
    retrieveButton.addActionListener(this);
    exitButton = new JButton("Exit");
    exitButton.addActionListener(this);

    JPanel buttonPanel = new JPanel();
    buttonPanel.add(addButton);
    buttonPanel.add(retrieveButton);
    buttonPanel.add(exitButton);
    frame.add(buttonPanel, BorderLayout.CENTER);

    recordsTextArea = new JTextArea(10,10);
    recordsTextArea.setEditable(false);
    frame.add(new JScrollPane(recordsTextArea), BorderLayout.SOUTH);

    frame.setVisible(true);

    }//end createAndShowGUI()

//------------------------------------------------------------------------------    
    
// In this method, construct a Student object that is initialized with the values entered by the user on the gui.   
// Send the object to the server.
// Clear the textfields and place the cursor in the name textfield    
    private static void addStudentRecord() {
        try {
            String name = nameField.getText();
            String id = idField.getText();
            int score = Integer.parseInt(scoreField.getText());
            
            Student student = new Student(name, id, score);
            
            out.writeObject(student);
            out.flush();
            System.out.println("Student record sent to server: " + student);

            nameField.setText("");
            idField.setText("");
            scoreField.setText("");
            nameField.requestFocus();
        } catch (IOException ex) {
            Logger.getLogger(StudentRecordClient.class.getName()).log(Level.SEVERE, null, ex);
        }
        

    }

//------------------------------------------------------------------------------    

// In this method, send a string to the server that indicates a retrieve request.
// Read the Arraylist Object sent from the server, and call the method to display the student records.
    private static void retrieveStudentRecords() {
        try {
            out.writeObject("retrieve");
            out.flush();

            Object receivedObject = in.readObject();

            if (receivedObject instanceof List<?>) {
                List<Student> studentList = (List<Student>) receivedObject;
                displayStudentRecords(studentList);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentRecordClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//------------------------------------------------------------------------------    

// In this method, you must append the records in the arraylist (sent as a parameter) in the textarea.
    private static void displayStudentRecords(List<Student> studentList) {
        recordsTextArea.setText("");
        for (Student student : studentList) {
            recordsTextArea.append(student.toString() + "\n");
        }

   }//end displayStudentRecords()

//------------------------------------------------------------------------------    

// Send a string value to the server indicating an exit request. 
// Read the returning string from the server
// Close all connections and exit the application    
    private static void closeConnection() {
        try {
            out.close();
            in.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }//end closeConnection()

//------------------------------------------------------------------------------    

// Handle all action events generated by the user-interaction with the buttons
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            addStudentRecord();
        } else if (e.getSource() == retrieveButton) {
            retrieveStudentRecords();
        } else if (e.getSource() == exitButton) {
            closeConnection();
        }

    }//end actionPerformed

//------------------------------------------------------------------------------    

// Execute the application by calling the necessary methods   
   public static void main(String[] args) {
       StudentRecordClient sr = new StudentRecordClient();
    }//end mai
}//end class

