/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnrollmentDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class EnrollmentDAO {
    private Connection connection;

    public EnrollmentDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean addEnrollment(Enrollment enrollment) {
        String insertQuery = "INSERT INTO Enrollments (studentNumber, courseCode) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, enrollment.getStudentNumber());
            preparedStatement.setString(2, enrollment.getCourseCode());
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean deleteEnrollment(String studentNumber, String courseCode) {
        String deleteQuery = "DELETE FROM Enrollments WHERE studentNumber = ? AND courseCode = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setString(1, studentNumber);
            preparedStatement.setString(2, courseCode);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean isStudentEnrolledInCourse(String studentNumber, String courseCode) {
        String checkQuery = "SELECT * FROM Enrollments WHERE studentNumber = ? AND courseCode = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(checkQuery)) {
            preparedStatement.setString(1, studentNumber);
            preparedStatement.setString(2, courseCode);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Enrollment> getEnrollmentsForStudent(String studentNumber) {
        List<Enrollment> enrollments = new ArrayList<>();
        String selectQuery = "SELECT * FROM Enrollments WHERE studentNumber = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
            preparedStatement.setString(1, studentNumber);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String courseCode = resultSet.getString("courseCode");
                enrollments.add(new Enrollment(studentNumber, courseCode));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enrollments;
    }
}
