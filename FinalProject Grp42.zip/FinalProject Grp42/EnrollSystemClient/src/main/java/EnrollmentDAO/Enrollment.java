/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnrollmentDAO;
import java.time.LocalDate;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class Enrollment {
    private String studentNumber;
    private String courseCode;
    
    public Enrollment() {
    }

    public Enrollment(String studentNumber, String courseCode) {
        this.studentNumber = studentNumber;
        this.courseCode = courseCode;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    @Override
    public String toString() {
        return "Enrollment{" + "studentNumber=" + studentNumber + ", courseCode=" + courseCode + '}';
    }
    
       
}

