package za.ac.cput.enrollsystemclient;

import CourseDAO.Course;
import CourseDAO.CourseDAO;
import DBConnection.DBConnection;
import StudentDAO.Student;
import StudentDAO.StudentDAO;
import UserDAO.UserDAO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import za.ac.cput.serversideenroll.EnrollmentRequest;
import java.util.List;

/**
 *
 * @author GROUP 42
 * Mngomezulu Allet
 * Maboya Martin
 * Moleba Kgololosego
 */
public class StudentEnrollmentClient {

    private JFrame frame;
    private JPanel loginPanel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, signupButton, searchButton;
    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static Socket socket;
    private JComboBox<String> courseComboBox;
    private JTextField searchField;
    private StudentDAO studentDAO;
    private CourseDAO courseDAO;
    private DefaultListModel<String> searchResultsModel;
    private JList<String> searchResultsList;

    public StudentEnrollmentClient() {

        try {
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();
            courseDAO = new CourseDAO(connection);

            frame = new JFrame("Student Enrollment System");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);
            frame.setLayout(new BorderLayout());

            loginPanel = new JPanel(new GridLayout(3, 2));

            JLabel usernameLabel = new JLabel("Username:");
            usernameField = new JTextField();
            loginPanel.add(usernameLabel);
            loginPanel.add(usernameField);

            JLabel passwordLabel = new JLabel("Password:");
            passwordField = new JPasswordField();
            loginPanel.add(passwordLabel);
            loginPanel.add(passwordField);

            loginButton = new JButton("Login");
            loginButton.setPreferredSize(new Dimension(150, 30));
            loginButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {

                        String enteredUsername = usernameField.getText();
                        char[] enteredPasswordChars = passwordField.getPassword();
                        String enteredPassword = new String(enteredPasswordChars);

                        if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                            JOptionPane.showMessageDialog(frame, "Please enter both username and password.", "Login Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        DBConnection dbconnection = new DBConnection();
                        Connection connection = dbconnection.getConnection();

                        UserDAO userDAO = new UserDAO(connection);

                        String role = userDAO.authenticate(enteredUsername, enteredPassword);
                        if (role != null && !role.isEmpty()) {
                            if ("admin".equalsIgnoreCase(role)) {
                                showAdminFunctionality();
                            } else if ("student".equalsIgnoreCase(role)) {
                                showStudentFunctionality();
                                JOptionPane.showMessageDialog(frame, "Login successful.", "Success", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(frame, "Unknown user role. Contact the administrator.", "Login Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(frame, "Invalid username or password. Please try again.", "Login Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
                        JOptionPane.showMessageDialog(frame, "Failed to connect to the database. Please try again later.", "Database Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
            signupButton = new JButton("Sign Up");
            signupButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        showSignupForm();
                    } catch (SQLException ex) {
                        Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            loginPanel.add(loginButton);
            loginPanel.add(signupButton);

            frame.add(buttonPanel, BorderLayout.SOUTH);
            frame.add(loginPanel, BorderLayout.CENTER);
            frame.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void showAdminFunctionality() {
        try {
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();

            frame.getContentPane().removeAll();
            frame.revalidate();
            frame.repaint();
            frame.setSize(600, 500);

            JPanel adminPanel = new JPanel(new BorderLayout());

            JLabel adminLabel = new JLabel("Admin Functionality");
            adminPanel.add(adminLabel, BorderLayout.NORTH);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

            JButton backToLoginButton = new JButton("Back to Login");
            backToLoginButton.setPreferredSize(new Dimension(150, 30));
            backToLoginButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.dispose();
                    new StudentEnrollmentClient();
                }
            });

            JButton addButton = new JButton("Add Course");
            addButton.setPreferredSize(new Dimension(150, 30));
            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Add Course Button clicked");
                    addNewCourse();
                }
            });

            JButton addStudentButton = new JButton("Add Student");
            addStudentButton.setPreferredSize(new Dimension(150, 30));
            addStudentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Add Student Button clicked");
                    addNewStudent();
                }
            });

            JButton displayCoursesButton = new JButton("Display Available Courses");
            displayCoursesButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayAvailableCourses();
                }
            });

            StudentDAO studentDAO = new StudentDAO(connection);
            var students = studentDAO.getAllStudents();
            String[] studentList = new String[students.size()];
            for (int i = 0; i < students.size(); i++) {
                studentList[i] = students.get(i).getStudentName();
            }

            JComboBox<String> studentComboBox = new JComboBox<>(studentList);
            studentComboBox.setPreferredSize(new Dimension(150, 30));

            JButton deleteStudentButton = new JButton("Delete Student");
            deleteStudentButton.setPreferredSize(new Dimension(150, 30));
            deleteStudentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selectedStudent = (String) studentComboBox.getSelectedItem();
                    if (selectedStudent != null) {
                        int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this student?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            deleteStudent(selectedStudent);
                        }
                    }
                }
            });

            JComboBox<String> courseComboBox = new JComboBox<>();
            DefaultComboBoxModel<String> courseComboBoxModel = new DefaultComboBoxModel<>();
            CourseDAO courseDAO = new CourseDAO(connection);
            var courses = courseDAO.getAllCourses();
            for (Course course : courses) {
                courseComboBoxModel.addElement(course.getCoursecode());
            }
            courseComboBox.setModel(courseComboBoxModel);

            JButton deleteCourseButton = new JButton("Delete Course");
            deleteCourseButton.setPreferredSize(new Dimension(150, 30));
            deleteCourseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String selectedCourse = (String) courseComboBox.getSelectedItem();
                    if (selectedCourse != null) {
                        int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this course?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            try {
                                CourseDAO courseDAO = new CourseDAO(connection);
                                courseDAO.deleteCourse(selectedCourse);
                                courseComboBoxModel.removeElement(selectedCourse);
                                JOptionPane.showMessageDialog(frame, "Course deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                            } catch (SQLException ex) {
                                Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            });

            JButton listAllStudentsButton = new JButton("List All Students");
            listAllStudentsButton.setPreferredSize(new Dimension(150, 30));
            listAllStudentsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    listAllStudents();
                }
            });

            JTextField searchField = new JTextField();
            searchField.setPreferredSize(new Dimension(150, 30));

            // Add "Search Student" button
            JButton searchStudentButton = new JButton("Search Student");
            searchStudentButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String studentNumber = searchField.getText();
                    List<Student> matchingStudents = searchStudentsByNumber(studentNumber);
                    displayStudents(matchingStudents);
                }
            });

            JTextField courseSearchField = new JTextField();
            courseSearchField.setPreferredSize(new Dimension(150, 30));
            JButton searchCoursesButton = new JButton("Search Courses");
            searchCoursesButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String searchQuery = courseSearchField.getText();
                    List<Course> matchingCourses = searchCourses(searchQuery);
                    displayCourses(matchingCourses);
                }
            });

            buttonPanel.add(addButton);
            buttonPanel.add(addStudentButton);
            buttonPanel.add(displayCoursesButton);
            buttonPanel.add(deleteStudentButton);
            buttonPanel.add(studentComboBox);
            buttonPanel.add(deleteCourseButton);
            buttonPanel.add(courseComboBox);
            buttonPanel.add(listAllStudentsButton);
            buttonPanel.add(searchField);
            buttonPanel.add(searchStudentButton);
            buttonPanel.add(courseSearchField);
            buttonPanel.add(searchCoursesButton);

            adminPanel.add(backToLoginButton, BorderLayout.SOUTH);
            adminPanel.add(buttonPanel, BorderLayout.CENTER);

            frame.add(adminPanel);
            frame.revalidate();
            frame.repaint();
        } catch (SQLException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void listAllStudents() {
        try {
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();
            StudentDAO studentDAO = new StudentDAO(connection);
            List<Student> students = studentDAO.listAllStudents();
            displayStudents(students);
        } catch (SQLException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private List<Student> searchStudentsByNumber(String studentNumber) {
        List<Student> matchingStudents = new ArrayList<>();

        if (studentNumber == null || studentNumber.trim().isEmpty() || studentDAO == null) {
            return matchingStudents;
        }

        try {
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();
            studentDAO = new StudentDAO(connection);

            Student student = studentDAO.getStudentByNumber(studentNumber);

            if (student != null) {
                matchingStudents.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return matchingStudents;
    }

    private List<Course> searchCourses(String query) {
        List<Course> matchingCourses = new ArrayList<>();

        if (query == null || query.trim().isEmpty()) {
            return matchingCourses;
        }

        try {
            if (courseDAO != null) {
                Course course = courseDAO.getCourseByCode(query);

                if (course != null) {
                    matchingCourses.add(course);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return matchingCourses;
    }

    private void displayStudents(List<Student> matchingStudents) {
        JFrame studentResultsFrame = new JFrame("Student Search Results");
        studentResultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel studentResultsPanel = new JPanel();

        DefaultTableModel studentTableModel = new DefaultTableModel();
        JTable studentTable = new JTable(studentTableModel);

        studentTableModel.addColumn("Student Name");
        studentTableModel.addColumn("Student Number");

        for (Student student : matchingStudents) {
            studentTableModel.addRow(new Object[]{student.getStudentName(), student.getStudentNumber()});
        }

        studentResultsPanel.add(new JScrollPane(studentTable));

        studentResultsFrame.add(studentResultsPanel);
        studentResultsFrame.setSize(800, 400);
        studentResultsFrame.setVisible(true);
    }

    private void displayCourses(List<Course> matchingCourses) {
        JFrame courseResultsFrame = new JFrame("Course Search Results");
        courseResultsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel courseResultsPanel = new JPanel();

        DefaultTableModel courseTableModel = new DefaultTableModel();
        JTable courseTable = new JTable(courseTableModel);

        courseTableModel.addColumn("Course Title");
        courseTableModel.addColumn("Course Code");
        courseTableModel.addColumn("Course Description");

        for (Course course : matchingCourses) {
            courseTableModel.addRow(new Object[]{course.getTitle(), course.getCoursecode(), course.getDescription()});
        }

        courseResultsPanel.add(new JScrollPane(courseTable));

        courseResultsFrame.add(courseResultsPanel);
        courseResultsFrame.setSize(800, 400);
        courseResultsFrame.setVisible(true);
    }

    private void deleteStudent(String studentName) {

        String request = "DeleteStudent";

        try {
            out.writeObject(request);
            out.writeObject(studentName);
            out.flush();
            Object response = in.readObject();

            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    private void sendDeleteCourseRequest(String courseTitle) {
        try {
            out.writeObject("DeleteCourse");
            out.writeObject(courseTitle);
            out.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void showSignupForm() throws SQLException {

        DBConnection dbConnection = new DBConnection();
        Connection connection = dbConnection.getConnection();

        JFrame signupFrame = new JFrame("Sign Up");
        signupFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        signupFrame.setSize(400, 200);
        signupFrame.setLayout(new BorderLayout());

        JPanel signupPanel = new JPanel(new GridLayout(4, 2));

        String[] roles = {"Student", "Admin"};
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();

        JButton signupButton = new JButton("Sign Up");
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String role = (String) roleComboBox.getSelectedItem();
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                UserDAO userDAO = new UserDAO(connection);
                if (userDAO.createUser(username, password, role)) {
                    JOptionPane.showMessageDialog(signupFrame, "Account created successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(signupFrame, "Failed to create the account. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                signupFrame.dispose();
            }
        });

        signupPanel.add(new JLabel("Role:"));
        signupPanel.add(roleComboBox);
        signupPanel.add(usernameLabel);
        signupPanel.add(usernameField);
        signupPanel.add(passwordLabel);
        signupPanel.add(passwordField);
        signupPanel.add(new JLabel());
        signupPanel.add(signupButton);
        signupFrame.add(signupPanel, BorderLayout.CENTER);
        signupFrame.setVisible(true);
    }

    private void showStudentFunctionality() {
        frame.getContentPane().removeAll();
        frame.revalidate();
        frame.repaint();

        JPanel studentPanel = new JPanel();
        studentPanel.setLayout(new BorderLayout());

        JLabel studentLabel = new JLabel("Student Functionality");
        studentPanel.add(studentLabel, BorderLayout.NORTH);

        JPanel courseActionsPanel = new JPanel(new FlowLayout());

        JButton enrollButton = new JButton("Enroll in Course");
        enrollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String studentNumber = JOptionPane.showInputDialog(frame, "Enter Student Number:");
                String courseCode = JOptionPane.showInputDialog(frame, "Enter Course Code:");

                if (studentNumber != null && courseCode != null) {
                    enrollStudentInCourse(studentNumber, courseCode);
                }
            }
        });

        courseActionsPanel.add(enrollButton);
        studentPanel.add(courseActionsPanel, BorderLayout.CENTER);
        JButton displayCoursesButton = new JButton("Display Available Courses");
        displayCoursesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayAvailableCourses();
            }
        });

        JButton backToLoginButton = new JButton("Back to Login");
        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backToLoginButton.setPreferredSize(new Dimension(150, 30));
        backToLoginButton.setPreferredSize(new Dimension(150, 30));
        backToLoginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.getContentPane().removeAll();
                frame.revalidate();
                frame.repaint();
                frame.dispose();
                new StudentEnrollmentClient();
            }
        });
        // Create a button for deregistering a student
        JButton deregisterButton = new JButton("Deregister Student");
        deregisterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement the functionality to deregister a student here
                deregisterStudent();
            }
        });
        courseActionsPanel.add(deregisterButton);

        courseActionsPanel.add(backToLoginButton);

        JPanel coursesDisplayPanel = new JPanel();
        coursesDisplayPanel.setLayout(new BorderLayout());
        coursesDisplayPanel.add(displayCoursesButton, BorderLayout.NORTH);

        studentPanel.add(coursesDisplayPanel, BorderLayout.SOUTH);

        frame.add(studentPanel);
        frame.setSize(600, 400);
        frame.revalidate();
        frame.repaint();
    }

    private void deregisterStudent() {
        String studentNumber = JOptionPane.showInputDialog("Enter the student number to deregister:");

        if (studentNumber != null && !studentNumber.isEmpty()) {
            try {
                out.writeObject("DeregisterStudent");
                out.writeObject(studentNumber);
                out.flush();

                String response = (String) in.readObject();
                boolean deregistrationSuccess = Boolean.parseBoolean(response);

                if (deregistrationSuccess) {
                    JOptionPane.showMessageDialog(null, "Student deregistered successfully", "Deregistration Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    //JOptionPane.showMessageDialog(null, "Failed to deregister the student", "Deregistration Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please enter a valid student number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addNewCourse() {

        JPanel coursePanel = new JPanel(new GridLayout(3, 2));

        JLabel courseCodeLabel = new JLabel("Course Code:");
        JTextField courseCodeField = new JTextField();
        coursePanel.add(courseCodeLabel);
        coursePanel.add(courseCodeField);

        JLabel courseNameLabel = new JLabel("Course Name:");
        JTextField courseNameField = new JTextField();
        coursePanel.add(courseNameLabel);
        coursePanel.add(courseNameField);

        JLabel courseDescriptionLabel = new JLabel("Course Description:");
        JTextField courseDescriptionField = new JTextField();
        coursePanel.add(courseDescriptionLabel);
        coursePanel.add(courseDescriptionField);

        int result = JOptionPane.showConfirmDialog(
                frame,
                coursePanel,
                "Add New Course",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result == JOptionPane.OK_OPTION) {
            String code = courseCodeField.getText();
            String name = courseNameField.getText();
            String description = courseDescriptionField.getText();

            if (code.isEmpty() || name.isEmpty() || description.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields must be filled.");
            } else {

                Course newCourse = new Course(code, name, description);

                sendNewCourseToServer(newCourse);

                JOptionPane.showMessageDialog(frame, "New course added successfully.");
            }
        }
    }

    public void connectToServer() {
        try {
            System.out.println("about to connect");
            socket = new Socket("127.0.0.1", 58304);
            System.out.println("creeating out");
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            System.out.println("creating in");
            in = new ObjectInputStream(socket.getInputStream());
            System.out.println("Connected to the server.");
        } catch (IOException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void sendNewCourseToServer(Course newCourse) {
        try {

            System.out.println("about to send request");
            out.writeObject("AddNewCourse");
            out.flush();
            out.writeObject(newCourse);
            out.flush();
            System.out.println("done");

            Object response = in.readObject();
            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void addNewStudent() {
        JPanel studentPanel = new JPanel(new GridLayout(2, 2));

        JLabel studentNumberLabel = new JLabel("Student Number:");
        JTextField studentNumberField = new JTextField();
        studentPanel.add(studentNumberLabel);
        studentPanel.add(studentNumberField);

        JLabel studentNameLabel = new JLabel("Student Name:");
        JTextField studentNameField = new JTextField();
        studentPanel.add(studentNameLabel);
        studentPanel.add(studentNameField);

        int result = JOptionPane.showConfirmDialog(
                frame,
                studentPanel,
                "Add New Student",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (result == JOptionPane.OK_OPTION) {
            String studentNumber = studentNumberField.getText();
            String studentName = studentNameField.getText();
            if (studentNumber.isEmpty() || studentName.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "All fields must be filled.");
            } else {
                Student newStudent = new Student(studentNumber, studentName);
                sendNewStudentToServer(newStudent);
                JOptionPane.showMessageDialog(frame, "New student added successfully.");
            }
        }

    }

    private void sendNewStudentToServer(Student newStudent) {
        try {
            out.writeObject("AddNewStudent");

            out.writeObject(newStudent);

            out.flush();

            Object response = in.readObject();
            if (response instanceof String) {
                String message = (String) response;
                JOptionPane.showMessageDialog(frame, message);
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void displayAvailableCourses() {

        try {

            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();

            CourseDAO courseDAO = new CourseDAO(connection);

            var availableCourses = courseDAO.getAllCourses();
            connection.close();

            if (!availableCourses.isEmpty()) {

                DefaultTableModel tableModel = new DefaultTableModel();
                tableModel.addColumn("Course Code");
                tableModel.addColumn("Course Title");
                tableModel.addColumn("Description");

                for (Course course : availableCourses) {
                    tableModel.addRow(new Object[]{course.getCoursecode(), course.getTitle(), course.getDescription()});
                }
                JTable courseTable = new JTable(tableModel);
                JScrollPane scrollPane = new JScrollPane(courseTable);
                JOptionPane.showMessageDialog(frame, scrollPane, "Available Courses", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "No available courses found.", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(frame, "Error fetching available courses.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void enrollStudentInCourse(String studentNumber, String courseCode) {
        try {
            out.writeObject("EnrollStudent");
            out.writeObject(studentNumber);
            out.writeObject(courseCode);
            out.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void sendEnrollmentRequest(EnrollmentRequest enrollmentRequest) {
        try {
            out.writeObject(enrollmentRequest);
        } catch (IOException ex) {
            Logger.getLogger(StudentEnrollmentClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {

        StudentEnrollmentClient client = new StudentEnrollmentClient();
        client.connectToServer();

    }
}
