/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class DBConnection {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:derby://localhost:1527/StudentEnrollmentDB";
        String administrator = "administrator";
        String password = "password";

        return DriverManager.getConnection(url, administrator, password);
    }
}
