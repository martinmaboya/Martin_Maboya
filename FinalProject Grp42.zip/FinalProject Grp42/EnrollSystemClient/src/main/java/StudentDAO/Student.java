/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StudentDAO;

import java.io.Serializable;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class Student implements Serializable {
    private String StudentNumber;
    private String StudentName;

    public Student() {
    }

    public Student(String StudentNumber, String StudentName) {
        this.StudentNumber = StudentNumber;
        this.StudentName = StudentName;
    }

    public String getStudentNumber() {
        return StudentNumber;
    }

    public void setStudentNumber(String StudentNumber) {
        this.StudentNumber = StudentNumber;
    }

    public String getStudentName() {
        return StudentName;
    }

    public void setStudentName(String StudentName) {
        this.StudentName = StudentName;
    }

    @Override
    public String toString() {
        return "Student{" + "StudentNumber=" + StudentNumber + ", StudentName=" + StudentName + '}';
    }
    
}
