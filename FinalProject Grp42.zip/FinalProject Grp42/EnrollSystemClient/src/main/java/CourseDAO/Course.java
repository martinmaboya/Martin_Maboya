/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CourseDAO;

import java.io.Serializable;

/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */
public class Course implements Serializable {
    private String coursecode;
    private String title;
    private String description; // Add description field

    public Course(int courseId, String code) {
    }

    public Course(String coursecode, String title, String description) {
        this.coursecode = coursecode;
        this.title = title;
        this.description = description;
    }

    public String getCoursecode() {
        return coursecode;
    }

    public void setCoursecode(String coursecode) {
        this.coursecode = coursecode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Course{" + "coursecode=" + coursecode + ", title=" + title + ", description=" + description + '}';
    }

}