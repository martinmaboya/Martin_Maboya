/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CourseDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */


public class CourseDAO {
    private Connection connection;

    public CourseDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new course in the database
    public void createCourse(Course course) throws SQLException {
        String insertSQL = "INSERT INTO courses (coursecode, title, description) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            preparedStatement.setString(1, course.getCoursecode());
            preparedStatement.setString(2, course.getTitle());
            preparedStatement.setString(3, course.getDescription());
            preparedStatement.executeUpdate();
        }
    }

    public Course getCourseByCode(String code) {
        String sql = "SELECT * FROM courses WHERE coursecode = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, code);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return new Course(
                        resultSet.getString("coursecode"),
                        resultSet.getString("title"),
                        resultSet.getString("description")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle any potential exceptions
        }
        return null;
    }
    public List<Course> searchCourses(String code) {
    List<Course> matchingCourses = new ArrayList<>();
    String sql = "SELECT * FROM courses WHERE coursecode = ?";
    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        preparedStatement.setString(1, code);
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                Course course = new Course(
                    resultSet.getString("coursecode"),
                    resultSet.getString("title"),
                    resultSet.getString("description")
                );
                matchingCourses.add(course);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle any potential exceptions
    }
    return matchingCourses;
}


    public void updateCourse(Course course) throws SQLException {
        String updateSQL = "UPDATE courses SET title = ?, description = ? WHERE coursecode = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
            preparedStatement.setString(1, course.getTitle());
            preparedStatement.setString(2, course.getDescription());
            preparedStatement.setString(3, course.getCoursecode());
            preparedStatement.executeUpdate();
        }
    }

    public boolean deleteCourse(String courseCode) throws SQLException {
        String deleteSQL = "DELETE FROM courses WHERE coursecode = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            preparedStatement.setString(1, courseCode);
            preparedStatement.executeUpdate();
        }
        return false;
    }

    public List<Course> getAllCourses() throws SQLException {
        List<Course> courses = new ArrayList<>();
        String selectAllSQL = "SELECT * FROM courses";
        try (PreparedStatement preparedStatement = connection.prepareStatement(selectAllSQL)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Course course = new Course(
                        resultSet.getString("coursecode"),
                        resultSet.getString("title"),
                        resultSet.getString("description")
                    );
                    courses.add(course);
                }
            }
        }
        return courses;
    }
    
}