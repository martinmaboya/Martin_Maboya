/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package za.ac.cput.serversideenroll;

import CourseDAO.Course;
import CourseDAO.CourseDAO;
import DBConnection.DBConnection;
import EnrollmentDAO.Enrollment;
import EnrollmentDAO.EnrollmentDAO;
import StudentDAO.Student;
import StudentDAO.StudentDAO;
import UserDAO.UserDAO;
import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author GROUP 42
 * Mngomezulu Allet
 * Maboya Martin
 * Moleba Kgololosego
 */
public class StudentEnrollServer {
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private Object receivedObject;
    private static List<Student> studentDatabase;
    private StudentDAO studentDAO;
    private CourseDAO courseDAO;
    private UserDAO userDAO;
    private EnrollmentDAO enrollmentDAO;
    private Connection connection;

    public StudentEnrollServer() throws SQLException {
        try {
            
            DBConnection dbConnection = new DBConnection(); 
            Connection connection = dbConnection.getConnection(); 
            studentDAO = new StudentDAO(connection);
            courseDAO = new CourseDAO(connection);
            userDAO = new UserDAO(connection);
            enrollmentDAO = new EnrollmentDAO(connection);

            serverSocket = new ServerSocket(58304);
            System.out.println("Server listening on port 58304");
            clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getStreams() {
        try {
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(clientSocket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    public void processClient() {
        try {
            while (true) {
                receivedObject = in.readObject();

                if (receivedObject instanceof EnrollmentRequest) {
                    EnrollmentRequest request = (EnrollmentRequest) receivedObject;
                    String role = authenticateUser(request.getUsername(), request.getPassword());
                    if (role != null) {
                        if ("admin".equalsIgnoreCase(role)) {
                            // Assuming you have studentNumber and courseCode available, pass them here
                            String studentNumber = request.getStudent().getStudentNumber();
                            String courseCode = request.getCourse().getCoursecode();

                            boolean enrollmentSuccess = enrollStudent(studentNumber, courseCode);

                            // Send a response back to the client
                            if (enrollmentSuccess) {
                                out.writeObject("Enrollment successful");
                            } else {
                                out.writeObject("Enrollment failed");
                            }
                            out.flush();
                        } else if ("student".equalsIgnoreCase(role)) {
                            // Handle student-specific actions
                        }
                    } else {
                        out.writeObject("Authentication failed");
                        out.flush();
                    }
                } else if (receivedObject instanceof String) {
                    String receivedString = (String) receivedObject;
                    if (receivedString.equalsIgnoreCase("AddNewCourse")) {
                        System.out.println("Received AddNewCourse Request");
                        sendCourseDataToDatabase();
                    }else if (receivedString.equalsIgnoreCase("AddNewStudent")) {
                    // Handle "AddNewStudent" request
                    System.out.println("Received AddNewStudent Request");
                        try {
                            Student newStudent = (Student) in.readObject();

                            if (addStudentToDatabase(newStudent)) {
                                out.writeObject("Student added successfully");
                            } else {
                                out.writeObject("Student added successfully");
                            }
                            out.flush();
                        } catch (ClassNotFoundException | IOException ex) {
                            ex.printStackTrace();
                            out.writeObject("Error: Invalid data received for AddNewStudent");
                            out.flush();
                        }
                    } else if (receivedString.equalsIgnoreCase("EnrollStudent")) {                   
                        System.out.println("Received Enrollment Request");
                        String studentNumber = (String) in.readObject();
                        String courseCode = (String) in.readObject();
                        boolean enrollmentSuccess = enrollStudent(studentNumber, courseCode);
                        if (enrollmentSuccess) {
                            out.writeObject("Enrollment successful");
                        } else {
                            out.writeObject("Enrollment failed");
                        }
                        out.flush();
                              } else if (receivedString.equalsIgnoreCase("DeleteStudent")) {
                        System.out.println("Received DeleteStudent Request");
                        String studentName = (String) in.readObject();
                        boolean deletionSuccess = deleteStudentFromDatabase(studentName);
                        if (deletionSuccess) {
                            out.writeObject("Student deleted successfully");
                        } else {
                            out.writeObject("Student deleted successfully");
                        }
                        out.flush();
                       } else if (receivedObject instanceof String) {
                        if (receivedString.equalsIgnoreCase("DeleteCourse")) {
                            String courseTitle = (String) in.readObject();
                            boolean courseDeletionSuccess = deleteCourse(courseTitle);

                            if (courseDeletionSuccess) {
                                out.writeObject("Course deleted successfully");
                            } else {
                                out.writeObject("Failed to delete the course");
                            }
                            out.flush();
                        }else if (receivedString.equalsIgnoreCase("DeregisterStudent")) {
                        System.out.println("Received Deregister Student Request");
                        String studentNumber = (String) in.readObject();

                        boolean deregistrationSuccess = deregisterStudentFromDatabase(studentNumber);

                        out.writeObject(deregistrationSuccess);
                        out.flush();
                    }}
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    private boolean addStudentToDatabase(Student student) {
        try {
            
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();
            StudentDAO studentDAO = new StudentDAO(connection);

            if (studentDAO.addStudent(student)) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean deregisterStudentFromDatabase(String studentNumber) {
        try {
            DBConnection dbConnection = new DBConnection();
            Connection connection = dbConnection.getConnection();
            EnrollmentDAO enrollmentDAO = new EnrollmentDAO(connection);

            List<Enrollment> studentEnrollments = enrollmentDAO.getEnrollmentsForStudent(studentNumber);

            if (studentEnrollments.isEmpty()) {
                boolean studentDeleted = studentDAO.deleteStudent(studentNumber);
                if (studentDeleted) {
                    System.out.println("Student deleted successfully.");
                    return true;
                } else {
                   // System.out.println("Failed to delete student from Students table.");
                    return false;
                }
            } else {

            for (Enrollment enrollment : studentEnrollments) {
                boolean enrollmentDeleted = enrollmentDAO.deleteEnrollment(enrollment.getStudentNumber(), enrollment.getCourseCode());
                if (enrollmentDeleted) {
                    System.out.println("Enrollment deleted successfully: " + enrollment.getStudentNumber() + " - " + enrollment.getCourseCode());
                } else {
//                    System.out.println("Failed to delete enrollment: " + enrollment.getStudentNumber() + " - " + enrollment.getCourseCode());
//                    return false;
                }
            }

            boolean studentDeleted = studentDAO.deleteStudent(studentNumber);
            if (studentDeleted) {
                System.out.println("Student deleted successfully.");
                return true;
            } else {
                System.out.println("Failed to delete student from Students table.");
                return false;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    private boolean deleteCourse(String coursecode) {
       
        try {
            DBConnection dbConnection = new DBConnection(); 
            Connection connection = dbConnection.getConnection(); 
            CourseDAO courseDAO = new CourseDAO(connection);
            Course courseToDelete = (Course) courseDAO.getCourseByCode(coursecode);
            if (courseToDelete != null) {
                
                boolean deletionSuccess = courseDAO.deleteCourse(courseToDelete.getCoursecode());
                return deletionSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    private boolean deleteStudentFromDatabase(String studentName) {
        
        return studentDAO.deleteStudent(studentName);
    }
    public boolean enrollStudent(String studentNumber, String courseCode) throws IOException {
        
        Student student = (Student) studentDAO.getStudentByNumber(studentNumber);
        Course course = (Course) courseDAO.getCourseByCode(courseCode);
        if (student != null && course != null) {
            
            Enrollment enrollment = new Enrollment(studentNumber, courseCode);
            if (enrollmentDAO.addEnrollment(enrollment)) {
                String successMessage = "Enrollment successful for student: " + studentNumber +
                        " in course: " + courseCode;
                out.writeObject("Enrollment successful");
                JOptionPane.showMessageDialog(null, successMessage, "Enrollment Success", JOptionPane.INFORMATION_MESSAGE);
                
                return true;
            }
        }
        out.writeObject("Enrollment failed");
        out.flush();
        return false;
    }
    private void sendCourseDataToDatabase() {
        try {
            Course cs = (Course) in.readObject();
            courseDAO.createCourse(cs);
            System.out.println("Added course");
            out.writeObject("DOne");
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(StudentEnrollServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StudentEnrollServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StudentEnrollServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
    }
    private void sendCourseDataToAdmin() throws SQLException {
  
        try {
            
            List<Course> courses = courseDAO.getAllCourses();
            out.writeObject(courses);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void sendStudentDataToAdmin() {
        try {
            
            List<Student> students = studentDAO.getAllStudents();
            
            out.writeObject(students);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String authenticateUser(String username, String password) {
        return userDAO.authenticate(username, password);
    }

    private void closeConnection() {
        try {
            out.close();
            in.close();
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        studentDatabase = new ArrayList<>();
        StudentEnrollServer server = new StudentEnrollServer();
        server.getStreams();
        server.processClient();
        
    }
}
