/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.serversideenroll;
import CourseDAO.Course;
import StudentDAO.Student;
import java.io.Serializable;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class EnrollmentRequest implements Serializable {
    private String username;
    private String password;
    private Student student;
    private Course course;

    public EnrollmentRequest() {
    }

    public EnrollmentRequest(String username, String password, Student student, Course course) {
        this.username = username;
        this.password = password;
        this.student = student;
        this.course = course;
    }
    

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    @Override
    public String toString() {
        return "EnrollmentRequest{" + "username=" + username + ", password=" + password + ", student=" + student + ", course=" + course + '}';
    }
    
}


    