/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StudentDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Mngomezulu kgotlelelo Allet
 */

public class StudentDAO {
    private Connection connection;

    public StudentDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean addStudent(Student student) {
        String insertQuery = "INSERT INTO Students (studentName, studentNumber) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, student.getStudentName());
            preparedStatement.setString(2, student.getStudentNumber());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Student getStudentByNumber(String studentNumber) {
        String sql = "SELECT * FROM Students WHERE studentNumber = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, studentNumber);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String studentName = resultSet.getString("studentName");
                String foundStudentNumber = resultSet.getString("studentNumber");
                return new Student(studentName, foundStudentNumber);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; 
    }
    public List<Student> listAllStudents() {
        List<Student> students = new ArrayList<>();
        String selectQuery = "SELECT * FROM Students";
        try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String studentName = resultSet.getString("studentName");
                String studentNumber = resultSet.getString("studentNumber");
                students.add(new Student(studentName, studentNumber));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }


    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String selectQuery = "SELECT * FROM Students";
        try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String studentName = resultSet.getString("studentName");
                String studentNumber = resultSet.getString("studentNumber");
                students.add(new Student(studentName, studentNumber));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public void updateStudent(Student student) {
        String updateQuery = "UPDATE Students SET studentName = ? WHERE studentNumber = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setString(1, student.getStudentName());
            preparedStatement.setString(2, student.getStudentNumber());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean deleteStudent(String studentNumber) {
        String deleteQuery = "DELETE FROM Students WHERE studentNumber = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setString(1, studentNumber);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

